<?php 

$titulo="Consecionario";

include "components/head.php";

?>
<body>

    <?php include "components/header.php"; ?>
    
    <div class="container">
        <h1><?php echo $titulo; ?></h1>
    </div>

    <?php include "components/footer.php"; ?>

</body>