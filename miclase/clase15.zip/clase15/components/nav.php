<div class="container">
    <nav class="navbar">
    <ul class="nav nav-tabs justify-content-center">
        <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="postventa.php">Postventa</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="concesionarios.php">Concesionarios</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="promociones.php">Promociones</a>
        </li>   
        <li class="nav-item">
            <a class="nav-link" href="financiamiento.php">Financiamiento</a>
        </li>       
        <li class="nav-item">
            <a class="nav-link" href="contactenos.php">Contáctenos</a>
        </li>                                    
    </ul>
</nav>
</div>