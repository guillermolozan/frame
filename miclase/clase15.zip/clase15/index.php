<?php 

$titulo="Home";

include "components/head.php";

?>
<body>

    <?php include "components/header.php"; ?>
    
    <div class="container">
        <h1>Página principal</h1>
    </div>

    <?php include "components/footer.php"; ?>

</body>